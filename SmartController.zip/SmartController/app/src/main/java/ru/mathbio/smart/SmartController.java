package ru.mathbio.smart;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
//import android.os.Message;
import android.support.design.widget.FloatingActionButton;
//import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
//import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.ftdi.j2xx.D2xxManager;
import com.ftdi.j2xx.FT_Device;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;

//import java.util.ArrayList;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;

import static java.lang.System.arraycopy;
//import java.util.List;

public class SmartController extends AppCompatActivity {

    // j2xx
    public static D2xxManager ftD2xx = null;
    FT_Device ftDev;
    int DevCount = -1;
    int currentPortIndex = -1;
    int portIndex = -1;

    enum DeviceStatus {
        DEV_NOT_CONNECT,
        DEV_NOT_CONFIG,
        DEV_CONFIG
    }

    // log tag
    //final String TT = "Trace";

    long back_button_click_time;
    boolean bBackButtonClick = false;

    // graphical objects
    ScrollView scrollView;
    TextView readText;
    LineChart lineChart;
    RelativeLayout loadingPanel;
    FloatingActionButton fab;

    public Context global_context;
    boolean uart_configured = false;
    int smartFunction = R.id.action_OJIP;

    // thread to read the data
    SmartThread smartThread;
    boolean bReadTheadEnable = false;

    int Mirror[];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        // init UI objects
        scrollView = (ScrollView) findViewById(R.id.ReadField);
        readText = (TextView) findViewById(R.id.ReadValues);
        lineChart = (LineChart) findViewById(R.id.chart);
        loadingPanel = (RelativeLayout) findViewById(R.id.loadingPanel);
        fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setAlpha(0.25f);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                //        .setAction("Action", null).show();
                Measure();
            }
        });
        /////////////////////////////////////////////////////////////////////////

        Mirror = new int[256];
        for (int i=0; i<256; i++) Mirror[i] = reverseBitsByte(i);

        try  {
            ftD2xx = D2xxManager.getInstance(this);
        }
        catch (D2xxManager.D2xxException e) {
            //Log.e("SMART_F","getInstance fail!!");
        }

        global_context = this;
        smartThread = new SmartThread();
        smartThread.start();

        /* port */
        portIndex = 0;

        lineChart.getDescription().setEnabled(false);
        lineChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        lineChart.getAxis(YAxis.AxisDependency.LEFT).setAxisMinimum(0.f);
        lineChart.getAxis(YAxis.AxisDependency.RIGHT).setEnabled(false);
        lineChart.getXAxis().setAxisMinimum(-3.f);
        lineChart.getXAxis().setAxisMaximum(3.f);
        lineChart.getXAxis().setValueFormatter(new IAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                return String.valueOf(Math.pow(10., value));
            }
        });
        //lineChart.getLegend().setEnabled(false);

        //getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        findViewById(R.id.loadingPanel).setVisibility(View.GONE);

        /////////////////////////////////////////////////////////////////////////
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_smart_controller, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            startActivity(new Intent(SmartController.this, SmartSettings.class));
            return true;
        } else {
            smartFunction = id;
            Measure();
            return true;
        }

        //return super.onOptionsItemSelected(item);
    }
    ////////////////////////////////////////////////////////////////////////////////
// menu function -
    void clearGraph() {
        try {
            lineChart.clearValues();
            lineChart.clear();
            lineChart.invalidate();
        } catch(Exception e) {
        }
    }
    void Measure() {
        if (View.VISIBLE == loadingPanel.getVisibility()) {
            midToast("Measurement already in progress", Toast.LENGTH_SHORT);
            return;
        }
        if ((R.id.action_Demo != smartFunction) && (DeviceStatus.DEV_CONFIG != checkDevice())) {
            return;
        }

        clearGraph();
        readText.setText("");
        loadingPanel.setVisibility(View.VISIBLE);

        switch(smartFunction) {
            case R.id.action_Fo:

                smartThread.runCommand((byte)16); // Fo
                break;

            case R.id.action_OJIP:

                ComboMeasurement cm = new ComboMeasurement(0, 0, 200, 5000);
                if (cm.configure()) {
                    cm.run();
                } else {
                    String msg = "Error setting parameters";
                    readText.setText(msg);
                    midToast(msg, Toast.LENGTH_SHORT);
                    loadingPanel.setVisibility(View.GONE);
                    break;
                }
                break;

            case R.id.action_Demo:

                ////////////////////////////////////////////////////////////////////////////// Demo  +
                // Demo
                final int n = 1000;
                Entry[] le = new Entry[n];
                for (int i = 0; i < n; i++) {
                    float lt = (float) (6.5*i/n-3.);
                    double t = (float) Math.pow(10., lt);
                    le[i] = new Entry(lt, (float)(4000. - 1500.*Math.exp(-t/0.05)-400.*Math.exp(-t)-1400.*Math.exp(-t/50)+1000.*Math.exp(-t/700)));
                }

                LineDataSet lineDataSet;
                lineDataSet = new LineDataSet(Arrays.asList(le), "OJIP");
                lineDataSet.setAxisDependency(YAxis.AxisDependency.LEFT);
                lineDataSet.setLineWidth(2);
                lineDataSet.setColor(R.color.colorPrimaryDark);
                lineDataSet.setDrawCircles(false);
                lineDataSet.setDrawValues(false);
                lineDataSet.setValueTextSize(12);
                LineData lineData = new LineData(lineDataSet);
                lineChart.setData(lineData);
                lineChart.invalidate();
                loadingPanel.setVisibility(View.GONE);
                ////////////////////////////////////////////////////////////////////////////// Demo -
                break;
            default:
                loadingPanel.setVisibility(View.GONE);
                break;
        }
    }

    static byte lo(int n) {
        return (byte) (n & 255);
    }
    static byte hi(int n) {
        return (byte) ((n >> 8) & 255);
    }
    class ComboMeasurement {
        int k0_, k1_, k2_, k3_;
        byte state = 0;
        ComboMeasurement(int k0, int k1, int k2, int k3) {
            k0_ = k0; k1_ = k1; k2_ = k2; k3_ = k3;
            state = 1;
        }
        boolean configure() {
            boolean ret = true;
            smartThread.runCommand((byte)15, this); // configure
            return ret;
        }
        boolean run() {
            state = 3;
            smartThread.runCommand((byte)64, this); // run combo
            return true;
        }
    }

    // call this API to show message
    void midToast(String str, int showTime)
    {
        Toast toast = Toast.makeText(global_context, str, showTime);
        toast.setGravity(Gravity.CENTER_VERTICAL|Gravity.CENTER_HORIZONTAL , 0, 0);

        TextView v = (TextView) toast.getView().findViewById(android.R.id.message);
        v.setTextColor(Color.YELLOW);
        toast.show();
    }

    public void onAttachedToWindow()
    {
        super.onAttachedToWindow();
    }

    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        /*
        if(KeyEvent.KEYCODE_HOME == keyCode) {
            DLog.e(TT,"Home key pressed");
        }
        */
        return super.onKeyDown(keyCode, event);
    }

    public void onBackPressed()  {
        if(false == bBackButtonClick) {
            midToast("Are you sure you will exit the program? Press again to exit.", Toast.LENGTH_LONG);

            back_button_click_time = System.currentTimeMillis();
            bBackButtonClick = true;

            ResetBackButtonThread backButtonThread = new ResetBackButtonThread();
            backButtonThread.start();
        } else {
            super.onBackPressed();
        }
    }

    class ResetBackButtonThread extends Thread
    {
        public void run()
        {
            try  {
                Thread.sleep(3500);
            } catch (InterruptedException e) {e.printStackTrace();}

            bBackButtonClick = false;
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        createDeviceList();
        if(DevCount > 0) {
            connectFunction();
            setConfig();
        }
    }

    protected void onResume() {
        super.onResume();
        if(null == ftDev || false == ftDev.isOpen()) {
            //DLog.e(TT,"onResume - reconnect");
            createDeviceList();
            if(DevCount > 0) {
                connectFunction();
                setConfig();
            }
        }
    }

    protected void onPause() { super.onPause(); }

    protected void onStop() { super.onStop(); }

    protected void onDestroy() {
        disconnectFunction();
        android.os.Process.killProcess(android.os.Process.myPid());
        super.onDestroy();
    }

    // j2xx functions +
    public void createDeviceList()
    {
        int tempDevCount = ftD2xx.createDeviceInfoList(global_context);

        if (tempDevCount > 0) {
            if( DevCount != tempDevCount ) {
                DevCount = tempDevCount;
                currentPortIndex = 0;
            }
        } else {
            DevCount = -1;
            currentPortIndex = -1;
            String msg = "No SMART device found";
            readText.setText(msg);
            midToast(msg, Toast.LENGTH_SHORT);
        }
    }

    public void disconnectFunction()
    {
        DevCount = -1;
        currentPortIndex = -1;
        //bReadTheadEnable = false;
        try {
            Thread.sleep(50);
        }
        catch (InterruptedException e) {e.printStackTrace();}

        if(ftDev != null) {
            if( true == ftDev.isOpen()) {
                ftDev.close();
            }
        }
        readText.setText("Smart fluorometer disconnected");
        clearGraph();
    }

    public void connectFunction() {
        if( portIndex + 1 > DevCount) {
            portIndex = 0;
        }

        if( currentPortIndex == portIndex
                && ftDev != null
                && true == ftDev.isOpen() ) {
            //Toast.makeText(global_context,"Port("+portIndex+") is already opened.", Toast.LENGTH_SHORT).show();
            return;
        }
        /*
        D2xxManager.DriverParameters params = new D2xxManager.DriverParameters();
        //params.setMaxBufferSize(64);
        params.setMaxBufferSize(16384);
        */
        ftDev = ftD2xx.openByIndex(global_context, portIndex);//, params);
        //ftDev.setLatencyTimer((byte)2);
        uart_configured = false;

        if(ftDev == null) {
            midToast("Open port("+portIndex+") NG!", Toast.LENGTH_LONG);
            return;
        }

        if (true == ftDev.isOpen()) {
            currentPortIndex = portIndex;
            //Toast.makeText(global_context, "open device port(" + portIndex + ") OK", Toast.LENGTH_SHORT).show();
        }
        else {
            midToast("Open port("+portIndex+") NG!", Toast.LENGTH_LONG);
        }
    }

    DeviceStatus checkDevice() {
        if(ftDev == null || false == ftDev.isOpen()) {
            midToast("SMART flurometer is not connected",Toast.LENGTH_SHORT);
            return DeviceStatus.DEV_NOT_CONNECT;
        } else if(false == uart_configured) {
            midToast("SMART flurometer is not configured",Toast.LENGTH_SHORT);
            return DeviceStatus.DEV_NOT_CONFIG;
        } else {
            return DeviceStatus.DEV_CONFIG;
        }

    }

    void setConfig() {
        // configure port
        // reset to UART mode for 232 devices
        ftDev.setLatencyTimer((byte)2);
        ftDev.setBitMode((byte) 0, D2xxManager.FT_BITMODE_RESET);
        ftDev.setBaudRate(1000000);
        ftDev.setDataCharacteristics(D2xxManager.FT_DATA_BITS_8, D2xxManager.FT_STOP_BITS_2, D2xxManager.FT_PARITY_NONE);
        ftDev.setFlowControl(D2xxManager.FT_FLOW_NONE, (byte)0x11, (byte)0x13);
        //sendData(new byte[] {1, 1}); // analog power on
        smartThread.runCommand((byte)1); // analog power on
        String msg = "SMART connected on port " + portIndex;
        readText.setText(msg);
        midToast(msg, Toast.LENGTH_SHORT);
        uart_configured = true;
    }

    void sendData(byte[] buffer) {
        if (ftDev.isOpen() == false) {
            //DLog.e(TT, "SendData: device not open");
            Toast.makeText(global_context, "Device not open!", Toast.LENGTH_SHORT).show();
            return;
        }
        synchronized(ftDev) {
            //ftDev.purge((byte) (D2xxManager.FT_PURGE_RX | D2xxManager.FT_PURGE_TX));
            for (int i = 0; i < buffer.length; ) {
                ftDev.write(new byte[]{buffer[i]});
                if ((i++) < buffer.length) {
                    try {
                        Thread.sleep(5);
                    } catch (InterruptedException ex) {
                        Thread.currentThread().interrupt();
                    }
                }
            }
        }
    }

// j2xx functions -


    class SmartThread extends Thread  {
        byte cmd;
        int mNumBytes;
        long mTimeout;
        ComboMeasurement mCM;
        byte[] usbdata;
        boolean busy;
        boolean waitResult;
        int readcount;
        SmartThread() {
            busy = false;
            this.setPriority(MAX_PRIORITY);
        }
        boolean runCommand(byte cmd_id) {
            return runCommand(cmd_id, null);
        }
        boolean runCommand(byte cmd_id, ComboMeasurement cm) {
            if (busy) {
                return false;
            }
            busy = true;
            cmd = cmd_id;
            mCM = cm;
            mTimeout = 0;
            mNumBytes = 0;
            waitResult = true;
            byte[] out_cmd = null;
            switch(cmd) {
                case 15: // configure
                    out_cmd = new byte[]{15, 15,
                            lo(mCM.k0_), hi(mCM.k0_),
                            lo(mCM.k1_), hi(mCM.k1_),
                            lo(mCM.k2_),
                            lo(mCM.k3_), hi(mCM.k3_)};
                    break;
                //case 1: // analog power on
                //case 16: // single pulse
                //case 64: // combo measurement
                default:
                    out_cmd = new byte[] {cmd, cmd};
                    break;
            }
            switch(cmd) {
                case 15: // configure
                    mTimeout = 500;
                    mNumBytes = 7;
                    break;
                case 16: // single pulse
                    mTimeout = 500;
                    mNumBytes = 16;
                    break;
                case 64: // combo measurement
                    if (mCM != null) {
                        mTimeout = (long) Math.ceil(0.01*mCM.k2_ + 0.2*mCM.k3_) + 1000;
                        mNumBytes = (mCM.k2_ + mCM.k3_) * 16;
                        waitResult = true;
                    }
                    break;
            }
            if (out_cmd != null) {
                synchronized (ftDev) {
                    ftDev.purge((byte) (D2xxManager.FT_PURGE_RX | D2xxManager.FT_PURGE_TX));
                    //ftDev.restartInTask();
                    //ftDev.resetDevice();
                    sendData(out_cmd);
                }
            }
            if (mNumBytes > 0) {
                try {
                    synchronized(smartThread) {
                        smartThread.notify();
                        if (waitResult) {
                            smartThread.wait(mTimeout);
                        }
                    }
                }catch(Exception e){
                    Writer writer = new StringWriter();
                    e.printStackTrace(new PrintWriter(writer));
                    String s = writer.toString();
                    readText.setText("Notify: " + s);
                    loadingPanel.setVisibility(View.GONE);
                }
            } else {
                busy = false;
            }
            return true;
        }

        public void run() {
            bReadTheadEnable = true;
            while (true == bReadTheadEnable) {
                synchronized (smartThread) {
                    try {
                        smartThread.wait();
                    } catch (InterruptedException e) {
                        //
                    }
                }
                try {
                usbdata = new byte[mNumBytes];//USB_DATA_BUFFER
                readcount = 0;
                if ((mNumBytes > 0) && (ftDev != null)) {
                    //readcount =  ftDev.read(usbdata, mNumBytes, mTimeout);
                    ///*
                    //synchronized (ftDev) {
                    int bytesleft = mNumBytes;
                    long start = System.currentTimeMillis();
                    long end = start + mTimeout;
                    long timeout = mTimeout;
                    ArrayList<byte[]> usbdata_a = new ArrayList<byte[]>();
                    ArrayList<Integer> usbdata_n = new ArrayList<Integer>();
                    byte[] usbdata_r = usbdata;
                    final int CHUNK_SIZE = 8192; //16384;
                    while ((0 < bytesleft) && (0 < timeout)) { // read data in chunks up to internal d2xx driver buffer size
                        int rc0 = (CHUNK_SIZE < bytesleft) ? CHUNK_SIZE : bytesleft;
                        int rc1 = ftDev.getQueueStatus();
                        if (rc1 > rc0) rc1 = rc0;
                        if (rc1 > 0){
                            int r = ftDev.read(usbdata_r, rc1);
                            timeout = end - System.currentTimeMillis();
                            readcount += r;
                            bytesleft -= r;
                            usbdata_n.add(r);
                            if ((0 < bytesleft) && (0 < timeout)) {
                                usbdata_r = new byte[(CHUNK_SIZE < bytesleft) ? CHUNK_SIZE : bytesleft];
                                usbdata_a.add(usbdata_r);
                            }
                            try
                            {
                                Thread.sleep(50);
                            }
                            catch (InterruptedException e) {
                                //e.printStackTrace();
                            }
                        }
                        /*
                        int r = ftDev.read(usbdata_r, (CHUNK_SIZE < bytesleft) ? CHUNK_SIZE : bytesleft, timeout);
                        timeout = end - System.currentTimeMillis();
                        readcount += r;
                        bytesleft -= r;
                        usbdata_n.add(r);
                        if ((0 < bytesleft) && (0 < timeout)) {
                            usbdata_r = new byte[(CHUNK_SIZE < bytesleft) ? CHUNK_SIZE : bytesleft];
                            usbdata_a.add(usbdata_r);
                        }
                        */
                    }
                    int r_pos = usbdata_n.get(0);
                    for (int i=0; i<usbdata_a.size(); i++) { // merge chunks
                        arraycopy(
                                usbdata_a.get(i), 0, // from
                                usbdata, r_pos,             // to
                                usbdata_n.get(i+1));        // length
                        r_pos += usbdata_n.get(i+1);
                    }
                    //}
                    //*/
                }
                busy = false;
                if (waitResult) {
                    synchronized(smartThread) {
                        // may need to set return value before signaling
                        smartThread.notify();
                    }
                }
                if (mNumBytes == readcount) {
                    // OK
                    switch (cmd) {
                        /*
                        case 15: // configure
                            // ToDo: should check returned bytes
                            break;
                        */
                        case 16: // single pulse
                            new Handler(Looper.getMainLooper()).post(new Runnable() {
                                @Override
                                public void run() {
                                    SpannableString text = new SpannableString("Fo = " +
                                            String.valueOf(F(usbdata)) + "\n" +
                                            bytesToHex(usbdata,16));
                                    text.setSpan(new ForegroundColorSpan(Color.YELLOW), 0, 2, 0);
                                    readText.setText(text);
                                    loadingPanel.setVisibility(View.GONE);
                                }
                            });
                            break;
                        case 64: // combo measurement
                            if (mCM != null) {
                                /////////////////////////////////////////////////////////////// Combo +
                                new Handler(Looper.getMainLooper()).post(new Runnable() {
                                    @Override
                                    public void run() {
                                        try {
                                            SpannableString text = new SpannableString("OJIP\n");
                                            text.setSpan(new ForegroundColorSpan(Color.YELLOW), 0, 4, 0);
                                            readText.setText(text);
                                            readText.append(bytesToHex(usbdata,16) + "\n");

                                            Entry[][] lle;
                                            int n = mCM.k2_ + mCM.k3_; // mNumBytes / 16;
                                            lle = new Entry[9][];
                                            for (int k = 0; k < lle.length; k++) {
                                                lle[k] = new Entry[n];
                                            }

                                            for (int i = 0; i < mCM.k2_; i++) { // fast phase inverse order
                                                int j = mCM.k2_ + mCM.k3_ - i;
                                                float lt = (float) Math.log10(0.00685 + 0.01 * i);
                                                for (int k = 0; k < 8; k++) {
                                                    //float f =  256.f*usbdata[16*j-2*k]+usbdata[16*j-2*k-1];
                                                    float f = 256.f * Mirror[(int) usbdata[16 * j - 2 * k - 1] & 0xFF] + ((int)usbdata[16 * j - 2 * k - 2] & 0xFF);
                                                    //if (f > 65000.f) clip = true;
                                                    lle[k][i] = new Entry(lt, f);
                                                }
                                                lle[8][i] = new Entry(lt, F(usbdata, j-1));
                                            }

                                            for (int j = 1; j < mCM.k3_ + 1; j++) { // slow phase forward order
                                                int i = mCM.k2_ + j - 1;
                                                float lt = (float) Math.log10(0.00685 + 0.01 * mCM.k2_ + 0.2 * j);
                                                for (int k = 0; k < 8; k++) {
                                                    float f = 256.f * Mirror[(int) usbdata[16 * j - 2 * k - 1] & 0xFF] + ((int)usbdata[16 * j - 2 * k - 2] & 0xFF);
                                                    //if (f > 65000.f) clip = true;
                                                    lle[k][i] = new Entry(lt, f);
                                                }
                                                lle[8][i] = new Entry(lt, F(usbdata, j-1));
                                            }
                                            // dark recovery forward order
                                            ///////////////////////////////////////////////////////// Plot ch +
                                            LineDataSet[] lineDataSet = new LineDataSet[lle.length];
                                            for (int k = 0; k < lle.length; k++) {
                                                lineDataSet[k] = new LineDataSet(Arrays.asList(lle[k]), (8 > k) ? String.valueOf(k) : "F");
                                                lineDataSet[k].setAxisDependency(YAxis.AxisDependency.LEFT);
                                                lineDataSet[k].setLineWidth(2);
                                                //lineDataSet[k].setColor(R.color.colorPrimaryDark);
                                                lineDataSet[k].setDrawCircles(false);
                                                lineDataSet[k].setDrawValues(false);
                                                lineDataSet[k].setValueTextSize(12);
                                            }
                                            lineDataSet[0].setColor(Color.DKGRAY);
                                            lineDataSet[1].setColor(Color.BLUE);
                                            lineDataSet[2].setColor(Color.RED);
                                            lineDataSet[3].setColor(Color.GREEN);
                                            lineDataSet[4].setColor(Color.LTGRAY);
                                            lineDataSet[5].setColor(Color.CYAN);
                                            lineDataSet[6].setColor(Color.MAGENTA);
                                            lineDataSet[7].setColor(Color.YELLOW);
                                            lineDataSet[8].setColor(Color.BLACK);
                                            LineData lineData = new LineData(lineDataSet);
                                            lineChart.setData(lineData);
                                            lineChart.invalidate();

                                            loadingPanel.setVisibility(View.GONE);
                                            ///////////////////////////////////////////////////////// Plot ch -
                                            //*/
                                        }catch(Exception e){
                                            Writer writer = new StringWriter();
                                            e.printStackTrace(new PrintWriter(writer));
                                            String s = writer.toString();
                                            readText.append("\n\nPlot: " + s);
                                            loadingPanel.setVisibility(View.GONE);
                                        }
                                    }
                                });
                                /////////////////////////////////////////////////////////////// Combo -
                            }
                            break;
                    }
                } else {
                    //err = true;
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            readText.setText("Error: expected " + String.valueOf(mNumBytes) +
                                    " bytes, got " +String.valueOf(readcount) + "!");
                            loadingPanel.setVisibility(View.GONE);
                        }
                    });
                }
                }catch(Exception e){
                    Writer writer = new StringWriter();
                    e.printStackTrace(new PrintWriter(writer));
                    final String s = writer.toString();
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            readText.setText("Tread: " + s);
                            loadingPanel.setVisibility(View.GONE);
                        }
                    });
                }
            }
        }
    }


    private final static char[] hexArray = "0123456789ABCDEF".toCharArray();
    static String bytesToHex(byte[] bytes) {
        return bytesToHex(bytes, bytes.length);
    }
    static String bytesToHex(byte[] bytes, int n) {
        char[] hexChars = new char[n * 3];
        for ( int j = 0; j < n; j++ ) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 3] = hexArray[v >>> 4];
            hexChars[j * 3 + 1] = hexArray[v & 0x0F];
            hexChars[j * 3 + 2] = ' ';
        }
        return new String(hexChars);
    }

    float F(byte[] usbdata) {
        return F(usbdata, 0);
    }
    float F(byte[] usbdata, int offset) {
        float ret = 0.f;
        for (int k = 0; k < 8; k++) {
            float chan = 256.f * Mirror[(int) usbdata[(offset + 1) * 16 - 2 * k - 1] & 0xFF] +
                    ((int)usbdata[(offset + 1) * 16 - 2 * k - 2] & 0xFF);
            if (chan > 65000.f) chan = Float.POSITIVE_INFINITY;
            if (k > 3) chan *= -1.f;
            ret += chan;
        }
        return ret;
    }

    /**************************************************************************
     * Author: Isai Damier
     * Title: Reverse Bits of Byte (8-bit)
     * Project: geekviewpoint
     * Package: algorithms
     *
     * Statement:
     *   Given an integer, reverse its bit sequence.
     *
     * Sample Input:  00100110
     * Sample Output: 01100100
     **************************************************************************/
    public static int reverseBitsByte(int x) {
        int intSize = 8;
        int y=0;
        for(int position=intSize-1; position>=0; position--){
            y+=((x&1)<<position);
            x >>= 1;
        }
        return y;
    }
}
